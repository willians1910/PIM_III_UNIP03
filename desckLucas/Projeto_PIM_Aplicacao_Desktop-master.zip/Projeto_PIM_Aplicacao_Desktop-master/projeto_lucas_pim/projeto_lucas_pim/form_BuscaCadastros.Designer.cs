﻿namespace projeto_lucas_pim
{
    partial class form_BuscaCadastros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.cbTipoBusca = new System.Windows.Forms.ComboBox();
            this.lblTipoBusca = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTipoBuscaCpf = new System.Windows.Forms.TextBox();
            this.lblTipoBuscaCNPJ = new System.Windows.Forms.Label();
            this.txtTipoBuscaCNPJ = new System.Windows.Forms.TextBox();
            this.lblTipoBuscaCNH = new System.Windows.Forms.Label();
            this.txtTipoBuscaCNH = new System.Windows.Forms.TextBox();
            this.txtTipoBuscaRenavam = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 39);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(773, 438);
            this.dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(327, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cadastros";
            // 
            // cbTipoBusca
            // 
            this.cbTipoBusca.FormattingEnabled = true;
            this.cbTipoBusca.Location = new System.Drawing.Point(130, 543);
            this.cbTipoBusca.Name = "cbTipoBusca";
            this.cbTipoBusca.Size = new System.Drawing.Size(121, 21);
            this.cbTipoBusca.TabIndex = 2;
            // 
            // lblTipoBusca
            // 
            this.lblTipoBusca.AutoSize = true;
            this.lblTipoBusca.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoBusca.Location = new System.Drawing.Point(323, 490);
            this.lblTipoBusca.Name = "lblTipoBusca";
            this.lblTipoBusca.Size = new System.Drawing.Size(123, 20);
            this.lblTipoBusca.TabIndex = 3;
            this.lblTipoBusca.Text = "Tipo de Busca";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 544);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Buscar por:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(277, 544);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "CPF:";
            // 
            // txtTipoBuscaCpf
            // 
            this.txtTipoBuscaCpf.Location = new System.Drawing.Point(327, 543);
            this.txtTipoBuscaCpf.Name = "txtTipoBuscaCpf";
            this.txtTipoBuscaCpf.Size = new System.Drawing.Size(147, 20);
            this.txtTipoBuscaCpf.TabIndex = 6;
            // 
            // lblTipoBuscaCNPJ
            // 
            this.lblTipoBuscaCNPJ.AutoSize = true;
            this.lblTipoBuscaCNPJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoBuscaCNPJ.Location = new System.Drawing.Point(267, 578);
            this.lblTipoBuscaCNPJ.Name = "lblTipoBuscaCNPJ";
            this.lblTipoBuscaCNPJ.Size = new System.Drawing.Size(58, 20);
            this.lblTipoBuscaCNPJ.TabIndex = 7;
            this.lblTipoBuscaCNPJ.Text = "CPNJ:";
            // 
            // txtTipoBuscaCNPJ
            // 
            this.txtTipoBuscaCNPJ.Location = new System.Drawing.Point(327, 578);
            this.txtTipoBuscaCNPJ.Name = "txtTipoBuscaCNPJ";
            this.txtTipoBuscaCNPJ.Size = new System.Drawing.Size(147, 20);
            this.txtTipoBuscaCNPJ.TabIndex = 8;
            // 
            // lblTipoBuscaCNH
            // 
            this.lblTipoBuscaCNH.AutoSize = true;
            this.lblTipoBuscaCNH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoBuscaCNH.Location = new System.Drawing.Point(540, 544);
            this.lblTipoBuscaCNH.Name = "lblTipoBuscaCNH";
            this.lblTipoBuscaCNH.Size = new System.Drawing.Size(51, 20);
            this.lblTipoBuscaCNH.TabIndex = 9;
            this.lblTipoBuscaCNH.Text = "CNH:";
            // 
            // txtTipoBuscaCNH
            // 
            this.txtTipoBuscaCNH.Location = new System.Drawing.Point(597, 543);
            this.txtTipoBuscaCNH.Name = "txtTipoBuscaCNH";
            this.txtTipoBuscaCNH.Size = new System.Drawing.Size(147, 20);
            this.txtTipoBuscaCNH.TabIndex = 10;
            // 
            // txtTipoBuscaRenavam
            // 
            this.txtTipoBuscaRenavam.Location = new System.Drawing.Point(597, 577);
            this.txtTipoBuscaRenavam.Name = "txtTipoBuscaRenavam";
            this.txtTipoBuscaRenavam.Size = new System.Drawing.Size(147, 20);
            this.txtTipoBuscaRenavam.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(502, 575);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "Renavam:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DimGray;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(597, 490);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "BUSCAR";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // form_BuscaCadastros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 640);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtTipoBuscaRenavam);
            this.Controls.Add(this.txtTipoBuscaCNH);
            this.Controls.Add(this.lblTipoBuscaCNH);
            this.Controls.Add(this.txtTipoBuscaCNPJ);
            this.Controls.Add(this.lblTipoBuscaCNPJ);
            this.Controls.Add(this.txtTipoBuscaCpf);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblTipoBusca);
            this.Controls.Add(this.cbTipoBusca);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "form_BuscaCadastros";
            this.Text = "form_BuscaCadastros";
            this.Load += new System.EventHandler(this.form_BuscaCadastros_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbTipoBusca;
        private System.Windows.Forms.Label lblTipoBusca;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTipoBuscaCpf;
        private System.Windows.Forms.Label lblTipoBuscaCNPJ;
        private System.Windows.Forms.TextBox txtTipoBuscaCNPJ;
        private System.Windows.Forms.Label lblTipoBuscaCNH;
        private System.Windows.Forms.TextBox txtTipoBuscaCNH;
        private System.Windows.Forms.TextBox txtTipoBuscaRenavam;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
    }
}